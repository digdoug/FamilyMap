package com.example.lp1.familymap;

/**
 * Created by lp1 on 4/12/16.
 */
public class SearchActivityRowItems {
    int iconId;
    String text;
}
